
window.onload = function () {
    //document.getElementById("addItem").onclick = saveItem;
};

var myNodelist = document.getElementsByTagName("LI");
var i;
for (i = 0; i < myNodelist.length; i++) {
    var span = document.createElement("SPAN");
    var txt = document.createTextNode("\u00D7"); // makes the closing x
    span.className = "close";
    span.appendChild(txt);
    myNodelist[i].appendChild(span);
}
var close = document.getElementsByClassName("close");
var i;
for (i = 0; i < close.length; i++) {
    close[i].onclick = function() {
    this.parentElement.style.display = "none";
    }
}

var list = document.querySelector('ul');
list.addEventListener('click', function(ev) {
    if (ev.target.tagName === 'LI') {
        ev.target.classList.toggle('checked');
    }           
}, false);

var count = 0; // creates id  count for the UL

function newElement() {
    var li = document.createElement("li");        
    li.id = count;   
    var inputValue = document.getElementById("myInput").value;
    var ToDo = document.createTextNode(inputValue);
    li.appendChild(ToDo);

    var ul = document.createElement("ul");    
    ul.id = count;       
    var ToUl = document.createTextNode("");
    ul.appendChild(ToUl);

    var hr = document.createElement("hr");
    var br = document.createElement("br");
   
    var detailsDescriptionLI = document.createElement("li");
    detailsDescriptionLI.classList.add("details");
    var descriptionLI = "Description:    " +  document.getElementById("description").value;
    var description = document.createTextNode(descriptionLI);
    detailsDescriptionLI.appendChild(description);

    var detailsCategoryLI = document.createElement("li");  
    detailsCategoryLI.classList.add("details");
    var categoryLI = "Category:       " + document.getElementById("category").value;
    var category = document.createTextNode(categoryLI);
    detailsCategoryLI.appendChild(category);

    var detailsDateLI = document.createElement("li");
    detailsDateLI.classList.add("details");
    var dateAddedLI =  "Date added:     " + document.getElementById("dateAdded").value;
    var dateAdded = document.createTextNode(dateAddedLI);
    detailsDateLI.appendChild(dateAdded);


    if (inputValue === '') {
        document.getElementById("myInput").placeholder="You must input a task!";
    }
    else {
        document.getElementById("display").appendChild(li);
        document.getElementById("display").appendChild(ul);
        document.getElementById("display").appendChild(hr);

        document.getElementById(count).appendChild(detailsCategoryLI); 
        document.getElementById(count).appendChild(detailsDescriptionLI); 
        document.getElementById(count).appendChild(detailsDateLI); 
    }

    clearBoxes(); // this code clears the input boxes when something is entered and added to the to do list
     
    var span = document.createElement("SPAN");
    var txt = document.createTextNode("\u00D7");
    span.className = "close";
    span.appendChild(txt);
    li.appendChild(span);

    count++;
  
    for (i = 0; i < close.length; i++) {
        close[i].onclick = function() {
            var div = this.parentElement;
            div.style.display = "none";

        }
    }
}

function clearBoxes() {
    document.getElementById("myInput").value = "";
    document.getElementById("category").value = "";
    document.getElementById("description").value = "";
    document.getElementById("dateAdded").value = "";

}

function hideTaskDetails(){
    var elems = document.getElementsByClassName('details');
    for (var i=0;i<elems.length;i+=1){
        elems[i].style.display = 'none';
    }
}

function showTaskDetails(){
    var elems = document.getElementsByClassName('details');
    for (var i=0;i<elems.length;i+=1){
        elems[i].style.display = 'block';
    }
}


