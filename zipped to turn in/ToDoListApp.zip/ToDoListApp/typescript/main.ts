/*
function test(){
    let item = new ToDoItem("test");
    let item2 = new ToDoItem("another");
}*/

window.onload = function(){
    document.getElementById("addItem").onclick =
        saveItem;

    document.getElementById("displayItems").onclick
        = displayItems;
}

let allItems:Array<ToDoItem> = [];

function saveItem(){
    //get info off form
    let itemTitle:string =
        (<HTMLInputElement>
        document.getElementById("title")).value;

    //create ToDoItem object
    let newTask = new ToDoItem(itemTitle);

    //save it!
    allItems.push(newTask);
}

function displayItems(){
    /*
    for(let i = 0; i < allItems.length; i++){
        
        let currItem:ToDoItem = allItems[i];
        alert(currItem.title);

        //same as above
        //alert(allItems[i].title);
    }
    */
    //same as above
    for(let currItem of allItems){
        alert(currItem.title);
    }

    /*
    //same loop as above
    allItems.forEach(currItem => {
        alert(currItem.title);
    });
    */
}