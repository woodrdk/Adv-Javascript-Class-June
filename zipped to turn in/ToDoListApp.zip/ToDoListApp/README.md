# ToDoListWeb
Simple example of a ToDoList in JavaScript/TypeScript created in class
