window.onload = function () {
    document.getElementById("addItem").onclick =
        saveItem;
    document.getElementById("displayItems").onclick
        = displayItems;
};
let allItems = [];
function saveItem() {
    let itemTitle = document.getElementById("title").value;
    let newTask = new ToDoItem(itemTitle);
    allItems.push(newTask);
}
function displayItems() {
    for (let currItem of allItems) {
        alert(currItem.title);
    }
}
class ToDoItem {
    constructor(title) {
        this.title = title;
    }
}
